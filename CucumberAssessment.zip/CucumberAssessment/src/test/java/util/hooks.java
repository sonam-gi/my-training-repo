package util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.Before;

public class hooks {
	
	public static WebDriver driver;
	
	@Before
	public void initdriver() {
		
		System.setProperty("webdriver.chrome.driver", "D:\\\\Selenium\\\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
	
	}

}

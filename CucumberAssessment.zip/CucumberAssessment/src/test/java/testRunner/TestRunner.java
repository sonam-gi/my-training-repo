package testRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= "src/test/java/feature_package",
		glue = {"stepDefinition", "util"},
		plugin= {"pretty",
				"html:target/Reports/Report_HTML.html",
				"json:target/Reports/Report_JSON.json",
				"junit:target/Reports/Report_JUNIT.xml"},
		monochrome= true)

public class TestRunner {

}
